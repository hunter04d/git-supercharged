module MyFunc

let func a b =
    a * b