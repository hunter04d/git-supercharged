﻿// Learn more about F# at http://fsharp.org

open System


open MyFunc

[<EntryPoint>]
let main argv =
    let x = func 3 2
    printfn "x = %i" x
    0 // return an integer exit code
