
#include <vector>
#include <algorithm>



int sum(const std::vector<double>& v) {
    double sum = 0;
    for(size_t i = 0; i < v.size(); ++i) {
        sum += v[i];
    }
    return sum;
}